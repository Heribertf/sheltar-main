-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Aug 06, 2024 at 01:42 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sheltarn_developers`
--

-- --------------------------------------------------------

--
-- Table structure for table `about`
--

CREATE TABLE `about` (
  `id` int(10) NOT NULL,
  `title` varchar(100) NOT NULL,
  `content` longtext NOT NULL,
  `image` varchar(300) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `about`
--

INSERT INTO `about` (`id`, `title`, `content`, `image`) VALUES
(10, 'About Our Company', '<div id=\"pgc-w5d0dcc3394ac1-0-0\" class=\"panel-grid-cell\">\r\n<div id=\"panel-w5d0dcc3394ac1-0-0-0\" class=\"so-panel widget widget_sow-editor panel-first-child panel-last-child\" data-index=\"0\">\r\n<div class=\"so-widget-sow-editor so-widget-sow-editor-base\">\r\n<div class=\"siteorigin-widget-tinymce textwidget\">\r\n<p class=\"text_all_p_tag_css\">Sheltar is an online listing platform that will enable individuals to search and secure affordable and quality housing. Additionally, we will also offer door to door moving services to our clients. Located in Eldoret, Kenya.</p>\r\n</div>\r\n</div>\r\n</div>\r\n</div>', 'condos-pool.png');

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `aid` int(10) NOT NULL,
  `auser` varchar(50) NOT NULL,
  `aemail` varchar(50) NOT NULL,
  `apass` varchar(50) NOT NULL,
  `adob` date NOT NULL,
  `aphone` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`aid`, `auser`, `aemail`, `apass`, `adob`, `aphone`) VALUES
(2, 'disha', 'disha@gmail.com', 'disha', '1999-02-02', '9689689698'),
(6, 'final', 'final@gmail.com', 'final', '2020-04-29', '7979656578'),
(7, 'test', 'test@gmail.com', 'test', '2020-04-29', '8997979765'),
(8, 'check', 'check@gmail.com', 'check', '2020-04-29', '8979785688'),
(9, 'admin', 'admin@gmail.com', 'admin', '1999-12-06', '9878786545'),
(10, 'John Macharia', 'johnmacharia@gmail.com', '1234', '1994-10-28', '0751078889');

-- --------------------------------------------------------

--
-- Table structure for table `city`
--

CREATE TABLE `city` (
  `cid` int(50) NOT NULL,
  `cname` varchar(100) NOT NULL,
  `sid` int(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `city`
--

INSERT INTO `city` (`cid`, `cname`, `sid`) VALUES
(9, 'navi mumbai', 3),
(10, 'vapi', 2),
(11, 'valsad', 2);

-- --------------------------------------------------------

--
-- Table structure for table `cmps`
--

CREATE TABLE `cmps` (
  `id` int(11) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `cmp` varchar(200) DEFAULT NULL,
  `username` varchar(200) DEFAULT NULL,
  `fullname` varchar(200) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `cmps`
--

INSERT INTO `cmps` (`id`, `name`, `cmp`, `username`, `fullname`) VALUES
(1, 'f', 'f', 'admin', 'Mahantesh Kumbar');

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE `contact` (
  `cid` int(50) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `subject` varchar(100) NOT NULL,
  `message` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `contact`
--

INSERT INTO `contact` (`cid`, `name`, `email`, `phone`, `subject`, `message`) VALUES
(2, 'demo', 'demo@gmail.com', '9765989689', 'demo', 'demo'),
(4, 'test', 'test@gmail.com', '7976976979', 'test', 'test'),
(5, 'final', 'final@gmail.com', '7697967967', 'final', 'final'),
(6, 'disha', 'disha@gmail.com', '7898797696', 'demo', 'demo'),
(7, 'gideon', 'ndugugideon@gmail.com', '+254703917', 'hello', 'reer'),
(8, 'Brenda Carney', 'rysyb@mailinator.com', '+1 (861) 814-2477', 'Voluptatibus eius fu', 'Qui est illo cupidi'),
(9, 'Aurelia Bouton', 'bouton.aurelia@gmail.com', '06-62406523', 'Dear sheltar.net Admin.', 'Want free traffic? Submit your website for free to over 35 classified ad sites here: http://freewebsitesubmission.12com.xyz/'),
(10, 'Colleen Yarborough', 'yarborough.colleen@hotmail.com', '(03) 8309 9784', 'To the sheltar.net Administrator.', 'Are you the owner of this site: http://sheltar.net? I am happy to inform you that you have been approved to place your submission to our free directory. Please go ahead and submit it by clicking on this link: http://freesubmission.12com.xyz/'),
(11, 'Blanche', 'info@theastrologerstrustofindia.com', '984 80 144', 'Sheltar - Contact US', 'Hi \r\n \r\nDefrost frozen foods in minutes safely and naturally with our THAW KINGâ„¢. \r\n\r\n50% OFF for the next 24 Hours ONLY + FREE Worldwide Shipping for a LIMITED \r\n\r\nBuy now: https://thawking.co\r\n \r\nBest regards, \r\n \r\nBlanche'),
(12, 'Onita Stopford', 'onita.stopford@outlook.com', '078 0156 6110', 'Hi sheltar.net Owner.', 'Are you the owner of this site: http://sheltar.net? I am happy to inform you that you have been approved to place your submission to our free directory. Please go ahead and submit it by clicking on this link: http://freewebsitesubmission.12com.xyz/');

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `id` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `message` text DEFAULT NULL,
  `status` int(11) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`id`, `uid`, `message`, `status`, `created_at`) VALUES
(1, 21, 'I was looking for a flat in Sinai and sheltar helped me all the way. I could choose not just the property but also got moving services.', 1, '2024-03-25 10:26:30'),
(2, 21, 'Sheltar made my dream of owning a home areality! From finding a home to moving in, this platform transformed house hunting into a seamless process.', 1, '2024-03-25 10:26:52'),
(3, 21, 'The guys at sheltar made my life easy. It helped me with the search for my first ever rental, I bedroom apartment in Eldoret. Thanks to the team behind sheltar.', 1, '2024-03-25 10:29:17'),
(4, 32, 'TORANAGASAMA', 1, '2024-03-26 03:39:45');

-- --------------------------------------------------------

--
-- Table structure for table `movers`
--

CREATE TABLE `movers` (
  `mover_id` int(11) NOT NULL,
  `mover_name` varchar(100) NOT NULL,
  `mover_email` varchar(100) NOT NULL,
  `mover_phone` varchar(50) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `delete_flag` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `movers`
--

INSERT INTO `movers` (`mover_id`, `mover_name`, `mover_email`, `mover_phone`, `status`, `delete_flag`) VALUES
(1, 'Mwas Movers', 'heribertfel20@gmail.com', '0768850167', 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `moving_request`
--

CREATE TABLE `moving_request` (
  `id` int(11) NOT NULL,
  `client_name` varchar(155) NOT NULL,
  `client_email` varchar(100) NOT NULL,
  `client_phone` varchar(20) NOT NULL,
  `current_address` varchar(155) NOT NULL,
  `destination_address` varchar(155) NOT NULL,
  `moving_date` timestamp NULL DEFAULT NULL,
  `request_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `rooms` int(11) NOT NULL,
  `additional_services` varchar(155) NOT NULL,
  `distance` float NOT NULL,
  `quote` float(10,2) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 2,
  `mover` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `moving_request`
--

INSERT INTO `moving_request` (`id`, `client_name`, `client_email`, `client_phone`, `current_address`, `destination_address`, `moving_date`, `request_date`, `rooms`, `additional_services`, `distance`, `quote`, `status`, `mover`) VALUES
(1, 'Felix Muimi', 'muimifelix69@gmail.com', '+254768850167', 'Ruiru, Kenya', 'Roysambu, Nairobi, Kenya', '2024-06-19 21:00:00', '2024-06-01 23:00:09', 3, 'packing, unpacking', 13.242, 32986.30, 2, NULL),
(2, 'Felix Muimi', 'muimifelix69@gmail.com', '+254768850167', 'Ruiru, Kenya', 'Kasarani, Nairobi, Kenya', '2024-06-26 21:00:00', '2024-06-01 23:36:23', 3, 'packing, unpacking', 13.367, 33005.05, 2, NULL),
(3, 'Felix Muimi', 'muimifelix19@gmail.com', '+254768850167', 'PR5C+5QG, Nairobi, Kenya', 'Roysambu, Nairobi, Kenya', '2024-06-12 21:00:00', '2024-06-05 12:21:20', 1, 'packing, unpacking', 12.599, 22889.85, 2, NULL),
(4, 'Felix Muimi', 'muimifelix69@gmail.com', '+254768850167', 'Roysambu, Nairobi, Kenya', 'Syokimau - Katani Rd, Kenya', '2024-06-06 21:00:00', '2024-06-05 12:44:50', 2, 'packing, unpacking', 27.011, 30051.65, 2, NULL),
(5, 'Felix Muimi', 'muimifelix69@gmail.com', '+254768850167', 'Roysambu, Nairobi, Kenya', 'Syokimau - Katani Rd, Kenya', '2024-06-06 21:00:00', '2024-06-05 12:45:51', 2, 'packing, unpacking', 27.011, 30051.65, 2, NULL),
(6, 'Felix Muimi', 'muimifelix69@gmail.com', '+254768850167', 'Roysambu, Nairobi, Kenya', 'Syokimau - Katani Rd, Kenya', '2024-06-06 21:00:00', '2024-06-05 12:48:38', 2, 'packing, unpacking', 27.011, 30051.65, 2, NULL),
(7, 'Felix Muimi', 'muimifelix69@gmail.com', '+254768850167', 'Roysambu, Nairobi, Kenya', 'Syokimau - Katani Rd, Kenya', '2024-06-06 21:00:00', '2024-06-05 12:49:00', 2, 'packing, unpacking', 27.011, 30051.65, 2, NULL),
(8, 'Felix Muimi', 'muimifelix69@gmail.com', '+254768850167', 'Roysambu, Nairobi, Kenya', 'Syokimau - Katani Rd, Kenya', '2024-06-06 21:00:00', '2024-06-05 13:31:23', 2, 'packing, unpacking', 27.011, 30051.65, 2, NULL),
(9, 'Felix Muimi', 'muimifelix69@gmail.com', '+254768850167', 'Roysambu, Nairobi, Kenya', 'Syokimau - Katani Rd, Kenya', '2024-06-06 21:00:00', '2024-06-05 13:31:34', 2, 'packing, unpacking', 27.011, 30051.65, 2, NULL),
(10, 'Felix Muimi', 'muimifelix69@gmail.com', '+254768850167', 'Roysambu, Nairobi, Kenya', 'Syokimau - Katani Rd, Kenya', '2024-06-06 21:00:00', '2024-06-05 13:36:38', 2, 'packing, unpacking', 27.011, 30051.65, 2, NULL),
(11, 'Felix Muimi', 'muimifelix69@gmail.com', '+254768850167', 'Roysambu, Nairobi, Kenya', 'Syokimau - Katani Rd, Kenya', '2024-06-06 21:00:00', '2024-06-05 13:38:18', 2, 'packing, unpacking', 27.011, 30051.65, 2, NULL),
(12, 'Felix Muimi', 'muimifelix19@gmail.com', '+254768850167', 'Ruiru, Kenya', 'Kabete, Kenya', '2024-06-19 21:00:00', '2024-06-11 17:11:01', 3, 'packing, unpacking', 38.489, 36773.35, 2, NULL),
(13, 'Patrick Nderu', 'patricknderu809@gmail.com', '+254768850167', 'Roysambu, Nairobi, Kenya', 'Syokimau, Nairobi, Kenya', '2024-06-21 21:00:00', '2024-06-11 17:13:07', 2, 'packing', 25.581, 26837.15, 2, NULL),
(14, 'Felix Muimi', 'muimifelix19@gmail.com', '+254768850167', 'Ruiru, Kenya', 'Roysambu, Nairobi, Kenya', '2024-06-18 21:00:00', '2024-06-11 17:26:13', 3, 'unpacking', 13.242, 32986.30, 2, NULL),
(15, 'Felix Muimi', 'muimifelix19@gmail.com', '+254768850167', 'RWXH+5JM, Ruiru, Kenya', 'Roysambu, Nairobi, Kenya', '2024-06-18 21:00:00', '2024-06-11 17:30:02', 4, 'packing', 16.192, 35428.80, 2, NULL),
(16, 'Felix Muimi', 'muimifelix19@gmail.com', '+254768850167', 'Ruiru, Kenya', 'Mwiki, Nairobi, Kenya', '2024-06-19 21:00:00', '2024-06-11 17:46:58', 3, 'packing, unpacking', 12.803, 32920.45, 2, NULL),
(17, 'Patrick Nderu', 'patricknderu809@gmail.com', '0798765432', 'Roysambu, Nairobi, Kenya', 'Kabete, Kenya', '2024-06-19 21:00:00', '2024-06-11 17:55:16', 3, 'packing, unpacking', 25.415, 34812.25, 2, NULL),
(18, 'Felix Muimi', 'muimifelix19@gmail.com', '+254768850167', 'Ruiru, Kenya', 'Roysambu, Nairobi, Kenya', '2024-06-20 21:00:00', '2024-06-11 18:01:45', 4, 'packing, unpacking', 13.242, 37986.30, 2, NULL),
(19, 'Felix Muimi', 'muimifelix19@gmail.com', '+254768850167', 'Ruiru, Kenya', 'Syokimau, Nairobi, Kenya', '2024-06-26 21:00:00', '2024-06-11 18:06:18', 3, 'packing, unpacking', 36.962, 36544.30, 2, NULL),
(20, 'Felix Muimi', 'muimifelix69@gmail.com', '+254768850167', 'Chuka, Kenya', 'Machakos, Kenya', '2024-06-16 21:00:00', '2024-06-11 18:07:53', 3, 'packing, unpacking', 200.842, 61126.30, 2, NULL),
(21, 'Felix Muimi', 'muimifelix69@gmail.com', '+254768850167', 'Chuka, Kenya', 'Machakos, Kenya', '2024-06-12 21:00:00', '2024-06-11 18:16:23', 4, 'packing, unpacking', 200.842, 66126.30, 2, NULL),
(22, 'Felix Muimi', 'muimifelix69@gmail.com', '+254768850167', 'Roysambu, Nairobi, Kenya', 'Ruiru, Kenya', '2024-06-19 21:00:00', '2024-06-11 18:32:39', 3, 'packing, unpacking', 12.859, 32928.85, 2, NULL),
(23, 'Felix Muimi', 'muimifelix19@gmail.com', '+254768850167', 'Roysambu, Nairobi, Kenya', 'Kabete, Kenya', '2024-06-20 21:00:00', '2024-06-13 13:26:07', 3, 'packing, unpacking', 25.415, 34812.25, 2, NULL),
(24, 'Patrick Nderu', 'patricknderu809@gmail.com', '0987654321', 'Roysambu, Nairobi, Kenya', 'Kabete, Kenya', '2024-06-20 21:00:00', '2024-06-13 13:33:45', 3, 'packing, unpacking', 25.415, 34812.25, 2, NULL),
(25, 'Felix Muimi', 'muimifelix69@gmail.com', '+254768850167', 'Ruiru, Kenya', 'Mwiki, Nairobi, Kenya', '2024-06-23 21:00:00', '2024-06-13 13:48:44', 2, 'packing', 12.803, 24920.45, 2, NULL),
(26, 'Felix Muimi', 'muimifelix69@gmail.com', '0768850167', 'Ruiru, Kenya', 'Kitengela, Kenya', '2024-06-14 21:00:00', '2024-06-13 13:56:13', 2, 'packing, unpacking, storage', 66.636, 37995.40, 2, NULL),
(27, 'Felix Muimi', 'muimifelix69@gmail.com', '+254768850167', 'Roysambu, Nairobi, Kenya', 'Mwiki, Nairobi, Kenya', '2024-06-19 21:00:00', '2024-06-18 18:42:10', 3, 'packing', 5.89, 28883.50, 2, NULL),
(28, 'felix', 'muimifelix19@gmail.com', '0768850167', 'Roysambu, Nairobi, Kenya', 'Kabete, Kenya', '2024-06-29 21:00:00', '2024-06-29 13:18:23', 3, 'packing', 25.415, 31812.25, 2, NULL),
(29, 'Morris', 'tutsmorris@gmail.com', '0796354101', 'Roysambu, Nairobi, Kenya', 'Syokimau, Nairobi, Kenya', '2024-07-04 21:00:00', '2024-06-29 13:21:26', 2, 'packing, unpacking', 25.593, 29838.95, 2, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `property`
--

CREATE TABLE `property` (
  `pid` int(50) NOT NULL,
  `title` varchar(200) NOT NULL,
  `pcontent` longtext NOT NULL,
  `type` varchar(100) NOT NULL,
  `stype` varchar(100) NOT NULL,
  `bedroom` int(50) NOT NULL,
  `floor` varchar(50) NOT NULL,
  `size` int(50) NOT NULL,
  `price` int(50) NOT NULL,
  `location` varchar(200) NOT NULL,
  `city` varchar(100) NOT NULL,
  `state` varchar(100) NOT NULL,
  `pimage` varchar(300) NOT NULL,
  `pimage1` varchar(300) NOT NULL,
  `pimage2` varchar(300) NOT NULL,
  `pimage3` varchar(300) NOT NULL,
  `pimage4` varchar(300) NOT NULL,
  `uid` int(50) NOT NULL,
  `status` varchar(50) NOT NULL,
  `date` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `property`
--

INSERT INTO `property` (`pid`, `title`, `pcontent`, `type`, `stype`, `bedroom`, `floor`, `size`, `price`, `location`, `city`, `state`, `pimage`, `pimage1`, `pimage2`, `pimage3`, `pimage4`, `uid`, `status`, `date`) VALUES
(11, 'final', '<p>final final final final final final final final final final final final final final final final final final final final final final final final final final final final final final final final final final final final final final final final final final final final final final final final final final final final final final final final final final final final final final final final final final final final final final final final final final final final final final final final final final final final final final final final final final final final final final final final final final final final final final final final final</p>\r\n<p>final final final final final final final final final final final final final final final final final final final final final final final final final final final final final final final final final final final final final final final final final final final final final final final final final final final final final final final final final final final final final final final final final final final final final final final final final final final final final final final final final final final final final final&nbsp;</p>\r\n<p>final final final final final final final final final final final final final final final final final final final final final final final final final final final final final final final final final final final final final final final final final final final final final final final final final final final final final final final final final final final final final final final final final final final final final final final final final final final final final final final final&nbsp;</p>', 'office', 'rent', 1, '3rd Floor', 4321, 897898, 'Kitale, off Nyati Road', 'Kitale, Kenya', 'Kitale', '1.jpg', '2.jpg', '3.jpg', '4.jpg', '5.jpg', 15, 'sold out', '2020-04-03 00:28:14'),
(15, 'New', '<p>New Test New Test New Test New Test New Test New Test New Test New Test New Test New Test New Test New Test New Test New Test New Test New Test New Test New Test New Test New Test New Test New Test New Test New Test New Test New Test New Test New Test New Test New Test New Test New Test New Test New Test New Test New Test New Test New Test New Test New Test New Test New Test New Test New Test New Test New Test New Test New Test New Test New Test New Test New Test New Test New Test New Test New Test New Test New Test New Test New Test New Test New Test New Test New Test New Test New Test New Test New Test New Test New Test New Test New Test New Test New Test New Test New Test New Test New Test New Test New Test New Test New Test New Test New Test New Test New Test New Test New Test New Test New Test New Test New Test New Test New Test New Test New Test New Test New Test New Test New Test New Test New Test New Test New Test New Test New Test New Test New Test New Test New Test New Test New Test New Test New Test New Test New Test New Test New Test New Test New Test New Test New Test New Test New Test New Test New Test New Test New Test New Test New Test New Test New Test New Test New Test New Test New Test New Test New Test New Test New Test New Test&nbsp;</p>', 'appartment', 'rent', 2, '2nd Floor', 1500, 1556000, 'Kitale, off Nyati Road', 'Kitale, Kenya', 'Kitale', '01.jpg', '02.jpg', '03.jpg', '04.jpg', '05.jpg', 15, 'available', '2020-04-03 14:45:49'),
(17, 'disha', '<p>disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha disha&nbsp;</p>', 'flat', 'rent', 2, '2nd Floor', 1500, 1550000, 'Kitale, off Nyati Road', 'Kitale, Kenya', 'Kitale', '01.jpg', '02.jpg', '03.jpg', '04.jpg', '05.jpg', 21, 'available', '2020-04-03 17:47:40'),
(18, 'new idea', '<p>new idea new idea new idea new idea new idea new idea new idea new idea new idea new idea new idea new idea new idea new idea new idea new idea new idea new idea new idea new idea new idea new idea new idea new idea new idea new idea new idea new idea new idea new idea new idea new idea new idea new idea new idea new idea new idea new idea new idea new idea new idea new idea new idea new idea new idea new idea new idea new idea new idea new idea new idea new idea new idea new idea new idea new idea new idea new idea new idea new idea new idea new idea new idea new idea new idea new idea new idea new idea new idea new idea new idea new idea new idea new idea new idea new idea new idea new idea new idea new idea new idea new idea new idea new idea new idea new idea new idea new idea new idea new idea new idea new idea new idea new idea new idea new idea new idea new idea new idea new idea new idea new idea new idea new idea new idea new idea new idea new idea new idea new idea new idea new idea new idea new idea new idea new idea new idea new idea new idea new idea new idea new idea new idea new idea new idea new idea new idea new idea new idea new idea new idea new idea&nbsp;</p>', 'flat', 'sale', 3, '1st Floor', 343, 34243423, 'vcxb', 'cxbvc', 'Thika', '1.jpg', '2.jpg', '3.jpg', '4.jpg', '5.jpg', 21, 'available', '2020-04-03 17:54:06'),
(19, 'testing', '<p>testing testing testing testing testing testing testing testing testing testing testing testing testing testing testing testing testing testing testing testing testing testing testing testing testing testing testing testing testing testing testing testing testing testing testing testing testing testing testing testing testing testing testing testing testing testing testing testing testing testing testing testing testing testing testing testing testing testing testing testing testing testing testing testing testing testing testing testing testing testing testing testing testing testing testing testing testing testing testing testing testing testing testing testing testing testing testing testing testing testing testing testing testing testing testing testing testing testing testing testing testing testing testing testing testing testing testing testing testing testing testing testing testing testing testing testing testing testing testing testing testing testing testing testing testing testing testing testing testing testing testing testing testing testing&nbsp;</p>', 'flat', 'rent', 2, '3rd Floor', 1250, 1500000, 'Kitale, off Nyati Road', 'Kitale, Kenya', 'Kitale', '11.jpg', '22.jpg', '33.jpg', '44.jpg', '55.jpg', 15, 'available', '2020-04-03 20:12:38'),
(22, 'By Faith Apartments', '<p>Magicbricks is an online platform where real estate trade is taking place in a much faster and newer manner. We not just help you with finding the ideal real estate, but also ensure that your buying journey is as smooth as it can be. We understand that while buying or renting a property, there are a lot of factors to be taken into consideration, like the locality, preferred area, budget, amenities, and a lot more. Magicbricks is the destination where you will end up finding the best suitable property available across India. Whether you are looking for a rented property or planning to build your dream abode, you can find anything and everything in real estate at our portal. We offer residential and commercial property listings for both sale and rent across the country. If you wish to make property investment in top cities, we present detailed information of various properties on sale, upcoming projects by renowned builders, budget residential apartments, commercial spaces, shops, etc. across cities like Bangalore, Pune, Mumbai, New Delhi, Chennai, Hyderabad, Kolkata, Noida, Gurgaon and many more. A wide variety of listing that is advertised here gives you an excellent overview of all property available in the area you are considering. Whether you are hunting for residential property, agricultural property, your next business set up, or an office space, Magicbricks aims at providing you the largest number of listing options in your preferred area to choose from.</p>', 'Flat', 'sale', 3, '2nd Floor', 1950, 4550467, 'main market near Little Saints school', 'Nairobi', 'Nairobi', '1.jpg', '2.jpg', '3.jpg', '4.jpg', '5.jpg', 16, 'sold out', '2020-04-04 01:38:36'),
(23, 'Imani Apartments', 'Imani apartments features bedsitters and one bedroom apartments', '', 'rent', 1, '1st Floor', 15000, 3000, 'Market road', 'Eld', 'Eldoret', 'Register 1.png', 'bamax background.jpg', 'bamax background.jpg', 'bamax background.jpg', 'bamax background.jpg', 29, 'available', '2022-01-28 15:03:16'),
(24, 'Big house Flats', 'Big house flats features bedsitters, One bedroom and two bedroom apartments', '', 'rent', 2, '1st Floor', 40500, 15000, 'Market road, opposite St. Luke church', 'Eldoret', 'Eldoret', 'bamax background.jpg', 'bamax background.jpg', 'bamax background.jpg', 'bamax background.jpg', 'bamax background.jpg', 30, 'available', '2022-01-28 15:20:16'),
(25, 'Leisure Living', 'Leisure Living is offering one of the most unique shopping experiences for outdoor patio furniture in Salt Lake City. ', '', 'rent', 1, '1st Floor', 100, 5000, '08, Stadium Road', 'Nakuru', 'Nakuru', 'Chrysanthemum.jpg', 'Desert.jpg', 'Jellyfish.jpg', 'Hydrangeas.jpg', 'Lighthouse.jpg', 50, 'available', '2022-12-14 16:17:30'),
(26, 'good property', '5 bedroom', '', 'rent', 5, '2nd Floor', 1500, 15000, 'Mariakani, Kapsoya', 'Eldoret', 'Rift Valley', 'Screenshot 2022-11-09 073702.jpg', 'Screenshot_20230708_201013_Reddit.jpg', 'Screenshot_20230708_201004_Reddit.jpg', '556f04f7-5402-423e-b3c7-43eb2f20bd13-original.jpeg', 'Screenshot_20230708_200939_Reddit.jpg', 51, 'available', '2023-07-11 10:12:18'),
(27, 'Urban village', 'osfasijfasjfk', '', 'rent', 1, '1st Floor', 44565474, 30000, '3025', 'Eldoret', 'eldoret', 'Untitled.png', 'Untitled.png', 'Untitled.png', 'Untitled.png', 'Untitled.png', 52, 'available', '2023-07-19 12:13:02');

-- --------------------------------------------------------

--
-- Table structure for table `property_request`
--

CREATE TABLE `property_request` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `property_category` varchar(50) NOT NULL,
  `property_type` varchar(50) NOT NULL,
  `rooms` int(11) DEFAULT NULL,
  `min_price` float(10,2) NOT NULL,
  `max_price` float(10,2) NOT NULL,
  `location` varchar(50) NOT NULL,
  `property_details` text DEFAULT NULL,
  `contact` varchar(20) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 2
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `property_request`
--

INSERT INTO `property_request` (`id`, `user_id`, `property_category`, `property_type`, `rooms`, `min_price`, `max_price`, `location`, `property_details`, `contact`, `status`) VALUES
(1, 32, 'Rent', 'Rent', 2, 10000.00, 20000.00, 'Roysambu', 'With open kitchen', '0987654321', 2),
(2, 32, 'Rent', 'Rent', 2, 10000.00, 20000.00, 'Roysambu', 'With open kitchen', '0987654321', 2),
(3, 32, 'Rent', 'Rent', 2, 10000.00, 20000.00, 'Roysambu', 'With open kitchen', '0987654321', 2),
(4, 32, 'Rent', 'Rent', 2, 10000.00, 20000.00, 'Roysambu', 'With open kitchen', '0987654321', 2),
(5, 32, 'Rent', 'Rent', 2, 10000.00, 20000.00, 'Roysambu', 'With open kitchen', '0987654321', 2),
(6, 32, 'Rent', 'Rent', 2, 10000.00, 20000.00, 'Roysambu', 'With open kitchen', '0987654321', 2),
(7, 32, 'Rent', 'Rent', 2, 10000.00, 20000.00, 'Roysambu', 'With open kitchen', '0987654321', 2),
(8, 32, 'Rent', 'Rent', 2, 10000.00, 20000.00, 'Roysambu', 'With open kitchen', '0987654321', 2),
(9, 32, 'Rent', 'Rent', 2, 10000.00, 20000.00, 'Roysambu', 'With open kitchen', '0987654321', 2),
(10, 32, 'Rent', 'Rent', 2, 10000.00, 15000.00, 'Kabete', 'A unit with open kitchen', '0987654321', 2),
(11, 28, 'Rent', 'Rent', 1, 10000.00, 20000.00, 'Nairobi', 'kITCHEN', '0708589852', 2),
(12, 32, 'Rent', 'Rent', 1, 15000.00, 30000.00, 'Kabete', 'With open kitchen', '0987654321', 2),
(13, 32, 'Rent', 'Rent', 3, 10000.00, 20000.00, 'Roysambu', 'With open kitchen', '0987654321', 2);

-- --------------------------------------------------------

--
-- Table structure for table `room_rental_registrations`
--

CREATE TABLE `room_rental_registrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `fullname` varchar(191) NOT NULL,
  `mobile` varchar(191) NOT NULL,
  `alternat_mobile` varchar(191) NOT NULL,
  `email` varchar(191) NOT NULL,
  `country` varchar(191) NOT NULL,
  `state` varchar(191) NOT NULL,
  `city` varchar(191) NOT NULL,
  `landmark` varchar(191) NOT NULL,
  `rent` varchar(191) NOT NULL,
  `sale` varchar(190) DEFAULT NULL,
  `deposit` varchar(191) NOT NULL,
  `plot_number` varchar(191) NOT NULL,
  `rooms` varchar(100) DEFAULT NULL,
  `address` varchar(191) NOT NULL,
  `accommodation` varchar(191) NOT NULL,
  `description` varchar(191) NOT NULL,
  `image` varchar(191) DEFAULT NULL,
  `open_for_sharing` varchar(191) DEFAULT NULL,
  `other` varchar(191) DEFAULT NULL,
  `vacant` int(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp(),
  `user_id` int(10) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `room_rental_registrations`
--

INSERT INTO `room_rental_registrations` (`id`, `fullname`, `mobile`, `alternat_mobile`, `email`, `country`, `state`, `city`, `landmark`, `rent`, `sale`, `deposit`, `plot_number`, `rooms`, `address`, `accommodation`, `description`, `image`, `open_for_sharing`, `other`, `vacant`, `created_at`, `updated_at`, `user_id`) VALUES
(13, 'Mahantesh Kumbar', '2345676567', '98888787', 'admin@admin.com', 'india', 'karnataka', 'Belagavi', 'aaaaaa', '3', '12', '3', '78 nh', '2bhk', 'dsdsd', '4', 'dssd', 'uploads/', NULL, 'zx', 0, '2018-02-16 12:21:43', '2018-02-16 12:21:43', 1),
(14, 'jelly fish', '2345676997', '', 'chet@gmrail.com', 'india', 'karnataka', 'Belagavi', '', '1232', '12', '33333', '78 nh', '1bhk', 'port road bgm', '', '', 'uploads/', NULL, NULL, 1, '2018-03-09 05:06:43', '2018-03-09 05:06:43', 2),
(15, 'aaa', '2222222222', '', 'admin@admmmin.com', 'india', 'karnataka', 'Belagavi', '', '1232', '12666', '33333', '78 nh', '1bhk', 'port road bgm', 'wifi,pridge', 'good to see', 'uploads/Penguins.jpg', NULL, NULL, 1, '2018-04-04 11:19:09', '2018-04-04 11:19:09', 1);

-- --------------------------------------------------------

--
-- Table structure for table `room_rental_registrations_apartment`
--

CREATE TABLE `room_rental_registrations_apartment` (
  `id` int(10) UNSIGNED NOT NULL,
  `fullname` varchar(191) NOT NULL,
  `mobile` varchar(191) NOT NULL,
  `alternat_mobile` varchar(191) NOT NULL,
  `email` varchar(191) NOT NULL,
  `country` varchar(191) NOT NULL,
  `state` varchar(191) NOT NULL,
  `city` varchar(191) NOT NULL,
  `landmark` varchar(191) NOT NULL,
  `rent` varchar(191) NOT NULL,
  `deposit` varchar(191) NOT NULL,
  `plot_number` varchar(191) NOT NULL,
  `apartment_name` varchar(100) DEFAULT NULL,
  `ap_number_of_plats` varchar(100) DEFAULT NULL,
  `rooms` varchar(100) DEFAULT NULL,
  `floor` varchar(100) DEFAULT NULL,
  `purpose` varchar(100) DEFAULT NULL,
  `own` varchar(100) DEFAULT NULL,
  `area` varchar(100) DEFAULT NULL,
  `address` varchar(191) NOT NULL,
  `accommodation` varchar(191) NOT NULL,
  `description` varchar(191) NOT NULL,
  `image` varchar(191) DEFAULT NULL,
  `open_for_sharing` varchar(191) DEFAULT NULL,
  `other` varchar(191) DEFAULT NULL,
  `vacant` int(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp(),
  `user_id` int(10) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `room_rental_registrations_apartment`
--

INSERT INTO `room_rental_registrations_apartment` (`id`, `fullname`, `mobile`, `alternat_mobile`, `email`, `country`, `state`, `city`, `landmark`, `rent`, `deposit`, `plot_number`, `apartment_name`, `ap_number_of_plats`, `rooms`, `floor`, `purpose`, `own`, `area`, `address`, `accommodation`, `description`, `image`, `open_for_sharing`, `other`, `vacant`, `created_at`, `updated_at`, `user_id`) VALUES
(3, 'mahantesh', '2345676567', '', 'admin@admddin.com', 'india', 'karnataka', 'Belagavi', 'near ramdev', '1212', '22222', '78 nh', 'mant apartment', '101', '2bhk', '2nd', 'Residential', 'rented', '1sqr feet', 'port road bgm', 'wifi', 'well ', 'uploads/Jellyfish.jpg', NULL, NULL, 1, '2018-04-04 11:20:56', '2018-04-04 11:20:56', 1);

-- --------------------------------------------------------

--
-- Table structure for table `state`
--

CREATE TABLE `state` (
  `sid` int(50) NOT NULL,
  `sname` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `state`
--

INSERT INTO `state` (`sid`, `sname`) VALUES
(2, 'Eldoret'),
(3, 'Kiambu'),
(4, 'Mombasa'),
(7, 'bihar'),
(9, 'Kitale'),
(10, 'uttar pardesh'),
(15, 'Isiolo');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `uid` int(50) NOT NULL,
  `uname` varchar(100) NOT NULL,
  `uemail` varchar(100) DEFAULT NULL,
  `uphone` varchar(20) DEFAULT NULL,
  `upass` varchar(50) DEFAULT NULL,
  `utype` varchar(50) NOT NULL,
  `uimage` varchar(300) DEFAULT NULL,
  `oauth_uid` varchar(50) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`uid`, `uname`, `uemail`, `uphone`, `upass`, `utype`, `uimage`, `oauth_uid`, `created_at`, `updated_at`) VALUES
(14, 'admin', 'admin@gmail.com', '9876543210', 'admin', 'user', '3.jpg', NULL, '2024-06-17 14:55:30', NULL),
(15, 'Jonathan', 'jonathan@gmail.com', '0788976542', 'jonathan', 'agent', '2.jpg', NULL, '2024-06-17 14:55:30', NULL),
(16, 'demo', 'demo@gmail.com', '7976976979', 'demo', 'user', '1.jpg', NULL, '2024-06-17 14:55:30', NULL),
(21, 'disha', 'disha@gmail.com', '7976956956', 'disha', 'agent', '2.jpg', NULL, '2024-06-17 14:55:30', NULL),
(22, 'jane', 'jane@gmail.com', '01120554663', 'jane', 'agent', '1.jpg', NULL, '2024-06-17 14:55:30', NULL),
(23, 'testing', 'testing@gmail.com', '9869596597', 'testing', 'builder', '1.jpg', NULL, '2024-06-17 14:55:30', NULL),
(24, 'some', 'some@gmail.com', '9689698697', 'some', 'builder', '3.jpg', NULL, '2024-06-17 14:55:30', NULL),
(25, 'test', 'test12@gmail.com', '9798678969', 'test', 'builder', 'avatar-3.jpg', NULL, '2024-06-17 14:55:30', NULL),
(28, 'John Macharia', 'kinyanjuimacharia15@gmail.com', '0700166997', '1234', 'user', 'bamax background.jpg', NULL, '2024-06-17 14:55:30', NULL),
(29, 'John Doe', 'john.doe@gmail.com', '0788976435', '1234', 'user', 'bamax background.jpg', NULL, '2024-06-17 14:55:30', NULL),
(30, 'Brian Jane', 'brianjane@gmail.com', '0789766679', '1234', 'builder', 'duke.jpg', NULL, '2024-06-17 14:55:30', NULL),
(31, 'Gideon', 'gideon@gmail.com', '0700166997', '1234', 'user', 'duke.jpg', NULL, '2024-06-17 14:55:30', NULL),
(32, 'Patrick Kimani', 'patricknderu809@gmail.com', '0708589852', '0708589852', 'user', 'IMG-20221014-WA0006.jpg', NULL, '2024-06-17 14:55:30', NULL),
(33, 'Kigz', 'brikigz@gmail.com', '0729545572', '0729545572', 'builder', 'koz.png', NULL, '2024-06-17 14:55:30', NULL),
(34, 'Kigz', 'DPOINO@YAHOO.COM', '0729545572', '0729545572', 'agent', 'koz.png', NULL, '2024-06-17 14:55:30', NULL),
(35, 'Kigz', 'kigobrian@gmail.com', '0729545572', '0729545572', 'user', 'koz.png', NULL, '2024-06-17 14:55:30', NULL),
(36, 'Brian Ndungu', 'obrienkiarie@gmail.com', '0728734113', '1000Acrefarm', 'user', '3765A7A6-5E7D-4A8A-8701-4D7376623419.jpeg', NULL, '2024-06-17 14:55:30', NULL),
(37, 'Joseph njoroge', 'josephmbeca20@gmail.com', '0798982194', '0798982194', 'user', '20210707_122855_0.jpg', NULL, '2024-06-17 14:55:30', NULL),
(38, 'SOLOMON MBUGUA', 'stainerthedj77@gmail.com', '0715276018', 'successfulds77.', 'user', 'IMG_20221002_223220.jpg', NULL, '2024-06-17 14:55:30', NULL),
(39, 'Brian', 'brianwaweru423@gmail.com', '0769818945', '0708589852', 'user', 'Screenshot_20221111-234516.jpg', NULL, '2024-06-17 14:55:30', NULL),
(40, 'keith', 'keithwamatha@gmail.com', '0715105851', 'wamatha001', 'user', 'spider man 3.jpg', NULL, '2024-06-17 14:55:30', NULL),
(41, 'Peter', 'Kariithipeter2018@gmail.com', '0708950971', '0122Peter ', 'user', 'IMG_20211004_080431_548.jpg', NULL, '2024-06-17 14:55:30', NULL),
(42, 'Fredrick', 'fredrickamaug@gmail.com', '0770537930', '12345678', 'user', '20221023_125838.jpg', NULL, '2024-06-17 14:55:30', NULL),
(43, 'Kelvin Gitu', 'gitukelvin01@gmail.com', '0703223308', 'Karimi001', 'user', 'IMG_20221108_141049_1.jpg', NULL, '2024-06-17 14:55:30', NULL),
(44, 'Fidelis ', 'fidelismutuku95@gmail.com', '0795121115', 'Mutuku2134', 'user', '16691871033485929892711494408497.jpg', NULL, '2024-06-17 14:55:30', NULL),
(45, 'Basil', 'basilmamba254@gmail.com', '0705450705', 'blackmamba', 'user', 'IMG_20210616_084823_667.jpg', NULL, '2024-06-17 14:55:30', NULL),
(46, 'Moureen wandia', 'moureenwandia@gmail.com', '0718637272', '0718637272', 'user', 'IMG-20210731-WA0151.jpg', NULL, '2024-06-17 14:55:30', NULL),
(47, 'John Lumbasi ', 'johnlumbasi13@gmail.com', '0708251787', 'Lumbasi777', 'user', 'IMG_hjgafo.jpg', NULL, '2024-06-17 14:55:30', NULL),
(48, 'Rashid urban', 'rashidurban@gmail.com', '0700264244', '0700264244', 'builder', 'Screenshot (1).png', NULL, '2024-06-17 14:55:30', NULL),
(49, 'James', 'james.james@gmail.com', '0765412890', '1234', 'builder', 'IMG_20221114_221226.jpg', NULL, '2024-06-17 14:55:30', NULL),
(50, 'Elizabeth', 'elizabeth254@gmail.com', '0788665431', '1234', 'agent', 'Koala.jpg', NULL, '2024-06-17 14:55:30', NULL),
(51, 'Vanessa Edwards', 'vanessaedwards216@gmail.com', '0768308768', 'jiji001', 'user', 'Screenshot_20230708_201013_Reddit.jpg', NULL, '2024-06-17 14:55:30', NULL),
(52, 'Dennis Murithi Kimathi', 'denniskimathi84@gmail.com', '0706679403', '0706679403', 'user', 'Untitled.png', NULL, '2024-06-17 14:55:30', NULL),
(53, 'Raph', 'raphaelnani3@gmail.com', '0759937610', '0759937610', 'user', 'EKA_Hotel.png', NULL, '2024-06-17 14:55:30', NULL),
(54, 'Ultra Shato', 'ultrashato@gmail.com', '0759937610', '0721405060', 'user', 'but.jpg', NULL, '2024-06-17 14:55:30', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `fullname` varchar(191) NOT NULL,
  `mobile` varchar(191) NOT NULL,
  `username` varchar(191) NOT NULL,
  `email` varchar(191) NOT NULL,
  `password` varchar(191) NOT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp(),
  `role` varchar(100) DEFAULT 'user',
  `status` int(1) NOT NULL DEFAULT 1
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `fullname`, `mobile`, `username`, `email`, `password`, `created_at`, `updated_at`, `role`, `status`) VALUES
(1, 'Mahantesh Kumbar', '9879879787', 'admin', 'admin@admin.com', '21232f297a57a5a743894a0e4a801fc3', NULL, NULL, 'admin', 1),
(2, 'Mahantesh Kumbar', '56456565', 'manu', 'mant1@gmail.com', '9aee390f19345028f03bb16c588550e1', '2018-02-08 06:53:53', '2018-02-08 06:53:53', 'user', 1);

-- --------------------------------------------------------

--
-- Table structure for table `verification`
--

CREATE TABLE `verification` (
  `verification_id` int(11) NOT NULL,
  `uid` int(11) DEFAULT NULL,
  `status` enum('Pending','Verified') DEFAULT 'Pending',
  `verification_date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `about`
--
ALTER TABLE `about`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`aid`);

--
-- Indexes for table `city`
--
ALTER TABLE `city`
  ADD PRIMARY KEY (`cid`);

--
-- Indexes for table `contact`
--
ALTER TABLE `contact`
  ADD PRIMARY KEY (`cid`);

--
-- Indexes for table `feedback`
--
ALTER TABLE `feedback`
  ADD PRIMARY KEY (`id`),
  ADD KEY `uid` (`uid`);

--
-- Indexes for table `movers`
--
ALTER TABLE `movers`
  ADD PRIMARY KEY (`mover_id`);

--
-- Indexes for table `moving_request`
--
ALTER TABLE `moving_request`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `property`
--
ALTER TABLE `property`
  ADD PRIMARY KEY (`pid`);

--
-- Indexes for table `property_request`
--
ALTER TABLE `property_request`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_user_id` (`user_id`);

--
-- Indexes for table `state`
--
ALTER TABLE `state`
  ADD PRIMARY KEY (`sid`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`uid`);

--
-- Indexes for table `verification`
--
ALTER TABLE `verification`
  ADD PRIMARY KEY (`verification_id`),
  ADD KEY `uid` (`uid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `about`
--
ALTER TABLE `about`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `aid` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `city`
--
ALTER TABLE `city`
  MODIFY `cid` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `contact`
--
ALTER TABLE `contact`
  MODIFY `cid` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `feedback`
--
ALTER TABLE `feedback`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `movers`
--
ALTER TABLE `movers`
  MODIFY `mover_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `moving_request`
--
ALTER TABLE `moving_request`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT for table `property`
--
ALTER TABLE `property`
  MODIFY `pid` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT for table `property_request`
--
ALTER TABLE `property_request`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `state`
--
ALTER TABLE `state`
  MODIFY `sid` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `uid` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=55;

--
-- AUTO_INCREMENT for table `verification`
--
ALTER TABLE `verification`
  MODIFY `verification_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `feedback`
--
ALTER TABLE `feedback`
  ADD CONSTRAINT `feedback_ibfk_1` FOREIGN KEY (`uid`) REFERENCES `user` (`uid`);

--
-- Constraints for table `property_request`
--
ALTER TABLE `property_request`
  ADD CONSTRAINT `fk_user_id` FOREIGN KEY (`user_id`) REFERENCES `user` (`uid`);

--
-- Constraints for table `verification`
--
ALTER TABLE `verification`
  ADD CONSTRAINT `verification_ibfk_1` FOREIGN KEY (`uid`) REFERENCES `user` (`uid`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
