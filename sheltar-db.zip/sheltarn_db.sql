-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Aug 06, 2024 at 01:40 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sheltarn_db`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `SubscriptionsExpiry` ()   UPDATE subscriptions
    SET status = 0
    WHERE sub_expiry < NOW()
    AND status = 1 OR status = 2$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `features`
--

CREATE TABLE `features` (
  `feature_id` int(11) NOT NULL,
  `feature_name` varchar(255) NOT NULL,
  `delete_flag` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `features`
--

INSERT INTO `features` (`feature_id`, `feature_name`, `delete_flag`) VALUES
(1, 'Listing Limit', 0),
(2, 'Support', 0),
(3, 'Profile Page', 0),
(4, 'Listing Visibility', 0),
(5, 'Marketing Tools', 0),
(6, 'Analytics', 0),
(7, 'Lead Management', 0);

-- --------------------------------------------------------

--
-- Table structure for table `plans`
--

CREATE TABLE `plans` (
  `plan_id` int(11) NOT NULL,
  `plan_name` varchar(155) NOT NULL,
  `plan_price` float(10,2) NOT NULL,
  `plan_features` varchar(255) DEFAULT NULL,
  `plan_status` enum('Active','Inactive') NOT NULL DEFAULT 'Inactive',
  `subscription_type` varchar(100) DEFAULT NULL,
  `delete_flag` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `plans`
--

INSERT INTO `plans` (`plan_id`, `plan_name`, `plan_price`, `plan_features`, `plan_status`, `subscription_type`, `delete_flag`) VALUES
(1, 'Basic', 2500.00, '1,2,3,4,5,6', 'Active', NULL, 0),
(2, 'Professional', 4500.00, '1,2,3,4,5,6,7', 'Active', NULL, 0),
(3, 'Premium', 6500.00, '1,2,3,4,5,6,7', 'Active', NULL, 0),
(4, 'Free', 1000.00, NULL, 'Inactive', NULL, 0);

-- --------------------------------------------------------

--
-- Table structure for table `property_listing`
--

CREATE TABLE `property_listing` (
  `listing_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `property_name` varchar(200) NOT NULL,
  `listing_type` tinyint(1) NOT NULL DEFAULT 1 COMMENT '1 - For Rent\r\n2 - For Sale',
  `property_use` tinyint(1) NOT NULL DEFAULT 1 COMMENT '1 - Residential\r\n2 - Commercial',
  `property_status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '1 - Unfurnished\r\n2 - Furnished',
  `property_type` tinyint(1) NOT NULL DEFAULT 1 COMMENT '1 - Apartment\r\n2 - Bungalow\r\n3 - Mansionette',
  `bedroom_count` int(11) NOT NULL,
  `unit_price` float(10,2) NOT NULL DEFAULT 0.00,
  `available_units` int(11) DEFAULT NULL,
  `total_units` int(11) DEFAULT NULL,
  `property_description` text NOT NULL,
  `features` varchar(350) NOT NULL,
  `image_paths` text NOT NULL,
  `city` varchar(155) NOT NULL,
  `address` varchar(155) NOT NULL,
  `latitude` varchar(200) DEFAULT NULL,
  `longitude` varchar(200) DEFAULT NULL,
  `added` timestamp NOT NULL DEFAULT current_timestamp(),
  `verification` tinyint(1) NOT NULL DEFAULT 2 COMMENT 'approval status',
  `delete_flag` tinyint(1) NOT NULL DEFAULT 0,
  `comment` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `property_listing`
--

INSERT INTO `property_listing` (`listing_id`, `user_id`, `property_name`, `listing_type`, `property_use`, `property_status`, `property_type`, `bedroom_count`, `unit_price`, `available_units`, `total_units`, `property_description`, `features`, `image_paths`, `city`, `address`, `latitude`, `longitude`, `added`, `verification`, `delete_flag`, `comment`) VALUES
(1, 1, 'Muthama Heights', 1, 1, 1, 1, 3, 230000.00, 14, 34, '<p><strong>Lorem Ipsum</strong> is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>', '', '663a9bbac51a1.png,663a9bbac5396.png,663a9bbac54d3.png,663a9bbac55b5.png', 'Chuka', '45, Ndagani', NULL, NULL, '2024-05-07 21:23:06', 0, 0, 'You are not verified to submit listings'),
(2, 1, 'Baraka Heights', 1, 1, 1, 1, 5, 450000.00, 13, 23, '<p>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here, content here\', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for \'lorem ipsum\' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).</p>', '', '663b30fb2fc1d.jpg,663b30fb2fc7c.jpg,663b30fb2fcab.jpg,663b30fb2fcd2.jpg', 'Chuka', '45, Ndagani', NULL, NULL, '2024-05-08 07:59:55', 1, 0, NULL),
(3, 1, 'Muthama Heights', 1, 1, 1, 1, 4, 350000.00, 12, 23, '<div>\r\n<div>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here, content here\', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for \'lorem ipsum\' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).</div>\r\n</div>', 'Master Ensuite,Parking,DSQ,Swimming,Gym,Own Compound', '663b33cb46571.jpg,663b33cb46931.jpg,663b33cb46b99.jpg,663b33cb46dd1.jpg', 'Chuka', '45, Ndagani', NULL, NULL, '2024-05-08 08:11:55', 2, 1, NULL),
(4, 1, 'Muthama Heights', 1, 1, 1, 1, 4, 330000.00, 12, 23, '<div>\r\n<div>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here, content here\', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for \'lorem ipsum\' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).</div>\r\n</div>', 'Master Ensuite,Parking,DSQ,Open Kitchen,Swimming,Internet,Gym,Security,Elevator,Own Compound', '663b342f73702.jpg,663b342f73750.jpg,663b342f7377d.jpg,663b342f737a5.jpg', 'Chuka', '45, Ndagani', NULL, NULL, '2024-05-08 08:13:35', 1, 0, NULL),
(5, 1, 'One bedroom apartment', 2, 1, 2, 1, 1, 4500000.00, NULL, NULL, '<p>This luxuriously large one bedroom apartment is a convenient choice for couples, individuals or even smaller families looking for a fully equipped apartment in a center of Prague. It is close to the most of major sights and surrounded by the picturesque streets of the historical Jewish quarter. Just one minute walk to the Pař&iacute;žsk&aacute; shopping boulevard and Vltava river. World-famous attractions like the Charles Bridge or the Old Town Square are just 5 minutes from the apartment. Whether you want to stay a few days or a couple of months, this apartment has all you need.</p>\r\n<p>The centerpiece of the apartment is the spacious living room with a modern cable flat-screen TV and a work desk ready for a relaxed fun or work with your laptop using our high-speed Wi-Fi. Living room also features a comfortable sofa and a murphy bed for two other people. A separate kitchen is fully equipped and has all you need for carefree cooking. In a quiet bedroom with a courtyard view you will find a comfortable king-sized bed and enough storage space. A bathroom has a standard-sized bath which can help you relax after a long day.</p>\r\n<p>The one bedroom apartments are located on the 1st, 2nd, 3rd and 4th floor and all of them offer a small balcony. The majestic art nouveau hall of the residence features an elevator for an easy access to your apartment. The house porter is available 12 hours a day, our 24/7 management office is ready to assist you anytime you need</p>', 'Parking,Open Kitchen,Swimming,Internet,Security,Elevator', '66706ec1e6587.jpg,66706ec1e6656.jpg,66706ec1e66b9.jpg,66706ec1e670f.jpg,66706ec1e6763.jpg,66706ec1e67b9.jpg', 'Ruiru', 'Kihunguro', NULL, NULL, '2024-06-17 17:13:37', 1, 0, NULL),
(6, 1, 'Two bedroom apartment', 1, 1, 1, 1, 2, 23000.00, NULL, NULL, '<p>Far far away, behind the word mountains, far from the countries Vokalia and Consonantia, there live the blind texts. Separated they live in Bookmarksgrove right at the coast of the Semantics, a large language ocean. A small river named Duden flows by their place and supplies it with the necessary regelialia. It is a paradisematic country, in which roasted parts of sentences fly into your mouth. Even the all-powerful Pointing has no control about the blind texts it is an almost unorthographic life One day however a small line of blind text by the name of Lorem Ipsum decided to leave for the far World of Grammar. The Big Oxmox advised her not to do so, because there were thousands of bad Commas, wild Question Marks and devious Semikoli, but the Little Blind Text didn&rsquo;t listen. She packed her seven versalia, put her initial into the belt and made herself on the way. When she reached the first hills of the Italic Mountains, she had a last view back on the skyline of her hometown Bookmarksgrove, the headline of Alphabet Village and the subline of her own road, the Line Lane. Pityful a rethoric question ran over her cheek, then</p>', 'Parking,Internet,Security', '669a2905071e9.jpeg,669a2905074f8.jpeg,669a290507568.jpeg,669a2905075ad.jpeg', 'Kasarani', 'Seasons', NULL, NULL, '2024-07-19 08:51:17', 1, 0, NULL),
(7, 1, 'Two bedroom apartment', 1, 1, 1, 1, 2, 23000.00, NULL, NULL, '<p>Far far away, behind the word mountains, far from the countries Vokalia and Consonantia, there live the blind texts. Separated they live in Bookmarksgrove right at the coast of the Semantics, a large language ocean. A small river named Duden flows by their place and supplies it with the necessary regelialia. It is a paradisematic country, in which roasted parts of sentences fly into your mouth. Even the all-powerful Pointing has no control about the blind texts it is an almost unorthographic life One day however a small line of blind text by the name of Lorem Ipsum decided to leave for the far World of Grammar. The Big Oxmox advised her not to do so, because there were thousands of bad Commas, wild Question Marks and devious Semikoli, but the Little Blind Text didn&rsquo;t listen. She packed her seven versalia, put her initial into the belt and made herself on the way. When she reached the first hills of the Italic Mountains, she had a last view back on the skyline of her hometown Bookmarksgrove, the headline of Alphabet Village and the subline of her own road, the Line Lane. Pityful a rethoric question ran over her cheek, then</p>', 'Parking,Open Kitchen,Internet,Security', '669a2b580bb76.jpeg,669a2b580bda6.jpeg,669a2b580be08.jpeg,669a2b580be50.jpeg', 'Kasarani', 'Seasons', '-1.2168535634554387', '36.90634846687317', '2024-07-19 09:01:12', 1, 0, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `subscriptions`
--

CREATE TABLE `subscriptions` (
  `sub_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `plan` int(11) NOT NULL,
  `sub_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `sub_expiry` timestamp NULL DEFAULT NULL,
  `transaction_ref` varchar(255) NOT NULL,
  `amount` float(10,2) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 2 COMMENT '1 - Active\r\n0 - Expired\r\n2 - Pending'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `subscriptions`
--

INSERT INTO `subscriptions` (`sub_id`, `user_id`, `plan`, `sub_date`, `sub_expiry`, `transaction_ref`, `amount`, `status`) VALUES
(1, 1, 2, '2024-07-18 05:54:16', '2024-08-17 07:54:25', '886777216', 4500.00, 1),
(4, 3, 2, '2024-08-02 22:23:23', '2024-09-01 21:23:32', 'SH32QZAWL8', 10.00, 1);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `first_name` varchar(100) DEFAULT NULL,
  `last_name` varchar(100) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `email` varchar(200) NOT NULL,
  `username` varchar(20) DEFAULT NULL,
  `password` varchar(100) DEFAULT NULL,
  `profileImage` varchar(255) DEFAULT NULL,
  `registerDate` datetime DEFAULT current_timestamp(),
  `verified` tinyint(1) NOT NULL DEFAULT 0,
  `delete_flag` tinyint(1) NOT NULL DEFAULT 0,
  `token` varchar(255) DEFAULT NULL,
  `token_expiry` datetime DEFAULT NULL,
  `code` int(11) DEFAULT NULL,
  `code_expiry` datetime DEFAULT NULL,
  `oauth_provider` enum('google','facebook','twitter','linkedin') DEFAULT NULL,
  `oauth_uid` varchar(50) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `modified` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  `type` tinyint(1) NOT NULL DEFAULT 3 COMMENT '1 - Admin,\r\n2 - Tenant,\r\n3 - Agent'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `first_name`, `last_name`, `phone`, `email`, `username`, `password`, `profileImage`, `registerDate`, `verified`, `delete_flag`, `token`, `token_expiry`, `code`, `code_expiry`, `oauth_provider`, `oauth_uid`, `created_at`, `modified`, `type`) VALUES
(1, 'Felix', 'Muimi', '+254768850167', 'heribertfel20@gmail.com', NULL, '$2y$10$YK9vp2MCYmd8meBgg.H3vOXQ1KPWq2EhkDV5.RonTUGObWB.cTNuC', '663bf99b4056e.jpg', '2024-05-07 15:04:16', 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '2024-06-06 12:53:00', '2024-06-14 13:47:05', 3),
(2, 'Felix', 'Developer', '0768850167', 'felixprogrammer76@gmail.com', NULL, '$2y$10$HFQpVSIUGFeLa9Xmo90kiOuZgxn1na87ElUplM2SnGHiczbSWYKYK', NULL, '2024-05-10 12:42:12', 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '2024-06-06 12:53:00', NULL, 1),
(3, 'TechBloom', NULL, NULL, 'techbloomsolutions@gmail.com', NULL, NULL, NULL, '2024-06-06 17:05:44', 0, 0, NULL, NULL, NULL, NULL, 'google', '100630579064540100025', '2024-06-06 14:05:44', NULL, 3),
(4, 'Patrick', 'Kimani', '0708589852', 'patricknderu809@gmail.com', NULL, '$2y$10$Iq5WjmoY99QMDLdEKPHzreiWGOsJq.XZn0/fotRas/lLLuVoAabrK', NULL, '2024-05-20 14:55:01', 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '2024-06-17 18:07:56', NULL, 3);

-- --------------------------------------------------------

--
-- Table structure for table `verification`
--

CREATE TABLE `verification` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `name` varchar(200) NOT NULL,
  `number` varchar(155) NOT NULL,
  `contact` varchar(50) NOT NULL,
  `document` varchar(255) NOT NULL,
  `type` enum('Agent','Landloard') NOT NULL,
  `submitted` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  `status` tinyint(1) NOT NULL DEFAULT 2,
  `comment` text DEFAULT NULL,
  `delete_flag` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `verification`
--

INSERT INTO `verification` (`id`, `user_id`, `name`, `number`, `contact`, `document`, `type`, `submitted`, `updated`, `status`, `comment`, `delete_flag`) VALUES
(1, 1, 'Techbloom Solutions', '123456', '0768850167', '../uploads/documents/663a913cdf856.pdf', 'Agent', '2024-05-08 10:51:24', '2024-05-10 09:11:21', 1, NULL, 0);

-- --------------------------------------------------------

--
-- Table structure for table `verified_agents`
--

CREATE TABLE `verified_agents` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `verification_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `verified_agents`
--

INSERT INTO `verified_agents` (`id`, `user_id`, `verification_date`, `updated`) VALUES
(1, 1, '2024-05-10 08:42:31', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `features`
--
ALTER TABLE `features`
  ADD PRIMARY KEY (`feature_id`);

--
-- Indexes for table `plans`
--
ALTER TABLE `plans`
  ADD PRIMARY KEY (`plan_id`);

--
-- Indexes for table `property_listing`
--
ALTER TABLE `property_listing`
  ADD PRIMARY KEY (`listing_id`),
  ADD KEY `fk_user_id` (`user_id`);

--
-- Indexes for table `subscriptions`
--
ALTER TABLE `subscriptions`
  ADD PRIMARY KEY (`sub_id`),
  ADD KEY `fk_user_id_subs` (`user_id`),
  ADD KEY `fk_plan_id` (`plan`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`);

--
-- Indexes for table `verification`
--
ALTER TABLE `verification`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_user_id_ver` (`user_id`);

--
-- Indexes for table `verified_agents`
--
ALTER TABLE `verified_agents`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_user_id_verified` (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `features`
--
ALTER TABLE `features`
  MODIFY `feature_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `plans`
--
ALTER TABLE `plans`
  MODIFY `plan_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `property_listing`
--
ALTER TABLE `property_listing`
  MODIFY `listing_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `subscriptions`
--
ALTER TABLE `subscriptions`
  MODIFY `sub_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `verification`
--
ALTER TABLE `verification`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `verified_agents`
--
ALTER TABLE `verified_agents`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `property_listing`
--
ALTER TABLE `property_listing`
  ADD CONSTRAINT `fk_user_id` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `subscriptions`
--
ALTER TABLE `subscriptions`
  ADD CONSTRAINT `fk_plan_id` FOREIGN KEY (`plan`) REFERENCES `plans` (`plan_id`),
  ADD CONSTRAINT `fk_user_id_subs` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`);

--
-- Constraints for table `verification`
--
ALTER TABLE `verification`
  ADD CONSTRAINT `fk_user_id_ver` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `verified_agents`
--
ALTER TABLE `verified_agents`
  ADD CONSTRAINT `fk_user_id_verified` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE;

DELIMITER $$
--
-- Events
--
CREATE DEFINER=`root`@`localhost` EVENT `subscriptions_expiry_event` ON SCHEDULE EVERY 1 DAY STARTS '2024-07-19 00:00:00' ON COMPLETION NOT PRESERVE ENABLE DO CALL `SubscriptionsExpiry`()$$

DELIMITER ;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
